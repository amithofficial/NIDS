﻿namespace Regression
{
    partial class ProcessMonitoring
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("");
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.lstnet = new System.Windows.Forms.ListBox();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.listView4 = new System.Windows.Forms.ListView();
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.lbt = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.lfs4 = new System.Windows.Forms.Label();
            this.lfs3 = new System.Windows.Forms.Label();
            this.lfs2 = new System.Windows.Forms.Label();
            this.lfs1 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.lstf = new System.Windows.Forms.ListView();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.lfa4 = new System.Windows.Forms.Label();
            this.lfa3 = new System.Windows.Forms.Label();
            this.lfa2 = new System.Windows.Forms.Label();
            this.lfa1 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.tabControl5 = new System.Windows.Forms.TabControl();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.lsvip = new System.Windows.Forms.ListView();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.lstpdet = new System.Windows.Forms.ListView();
            this.tabPage21 = new System.Windows.Forms.TabPage();
            this.lbpds = new System.Windows.Forms.Label();
            this.lbpd = new System.Windows.Forms.Label();
            this.lbrp = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.lbnfa = new System.Windows.Forms.Label();
            this.llbduc = new System.Windows.Forms.Label();
            this.tabPage22 = new System.Windows.Forms.TabPage();
            this.lstip = new System.Windows.Forms.ListBox();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.tabControl6 = new System.Windows.Forms.TabControl();
            this.tabPage23 = new System.Windows.Forms.TabPage();
            this.lstdns = new System.Windows.Forms.ListView();
            this.tabPage24 = new System.Windows.Forms.TabPage();
            this.tabPage25 = new System.Windows.Forms.TabPage();
            this.lsvdet = new System.Windows.Forms.ListView();
            this.button4 = new System.Windows.Forms.Button();
            this.lstadet = new System.Windows.Forms.ListView();
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.MemoryTimer = new System.Windows.Forms.Timer(this.components);
            this.Programstimer = new System.Windows.Forms.Timer(this.components);
            this.tmrEditNotify = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.tabPage15.SuspendLayout();
            this.tabPage16.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabControl5.SuspendLayout();
            this.tabPage17.SuspendLayout();
            this.tabPage20.SuspendLayout();
            this.tabPage21.SuspendLayout();
            this.tabPage22.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabControl6.SuspendLayout();
            this.tabPage23.SuspendLayout();
            this.tabPage25.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tabControl2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.button4);
            this.splitContainer1.Panel2.Controls.Add(this.lstadet);
            this.splitContainer1.Size = new System.Drawing.Size(1165, 514);
            this.splitContainer1.SplitterDistance = 885;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 0;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(0, 0);
            this.tabControl2.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(885, 514);
            this.tabControl2.TabIndex = 1;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.splitContainer3);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage6.Size = new System.Drawing.Size(877, 485);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "Probe Layer";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(4, 4);
            this.splitContainer3.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.tabControl3);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.tabControl4);
            this.splitContainer3.Size = new System.Drawing.Size(869, 477);
            this.splitContainer3.SplitterDistance = 431;
            this.splitContainer3.SplitterWidth = 5;
            this.splitContainer3.TabIndex = 0;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage10);
            this.tabControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl3.Location = new System.Drawing.Point(0, 0);
            this.tabControl3.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(431, 477);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.lstnet);
            this.tabPage10.Location = new System.Drawing.Point(4, 25);
            this.tabPage10.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage10.Size = new System.Drawing.Size(423, 448);
            this.tabPage10.TabIndex = 0;
            this.tabPage10.Text = "Selected Network";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // lstnet
            // 
            this.lstnet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstnet.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.lstnet.ForeColor = System.Drawing.Color.DimGray;
            this.lstnet.FormattingEnabled = true;
            this.lstnet.ItemHeight = 17;
            this.lstnet.Location = new System.Drawing.Point(4, 4);
            this.lstnet.Margin = new System.Windows.Forms.Padding(4);
            this.lstnet.Name = "lstnet";
            this.lstnet.Size = new System.Drawing.Size(415, 440);
            this.lstnet.TabIndex = 7;
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage13);
            this.tabControl4.Controls.Add(this.tabPage14);
            this.tabControl4.Controls.Add(this.tabPage15);
            this.tabControl4.Controls.Add(this.tabPage16);
            this.tabControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl4.Location = new System.Drawing.Point(0, 0);
            this.tabControl4.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(433, 477);
            this.tabControl4.TabIndex = 0;
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.listView4);
            this.tabPage13.Location = new System.Drawing.Point(4, 25);
            this.tabPage13.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage13.Size = new System.Drawing.Size(425, 448);
            this.tabPage13.TabIndex = 0;
            this.tabPage13.Text = "Files Modified";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // listView4
            // 
            this.listView4.BackColor = System.Drawing.Color.White;
            this.listView4.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10});
            this.listView4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.listView4.ForeColor = System.Drawing.SystemColors.InfoText;
            this.listView4.HideSelection = false;
            this.listView4.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1});
            this.listView4.Location = new System.Drawing.Point(4, 4);
            this.listView4.Margin = new System.Windows.Forms.Padding(4);
            this.listView4.Name = "listView4";
            this.listView4.Size = new System.Drawing.Size(417, 440);
            this.listView4.TabIndex = 17;
            this.listView4.UseCompatibleStateImageBehavior = false;
            this.listView4.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "File Path";
            this.columnHeader8.Width = 450;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Operation";
            this.columnHeader9.Width = 110;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Time";
            this.columnHeader10.Width = 210;
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.lbt);
            this.tabPage14.Controls.Add(this.label31);
            this.tabPage14.Controls.Add(this.lfs4);
            this.tabPage14.Controls.Add(this.lfs3);
            this.tabPage14.Controls.Add(this.lfs2);
            this.tabPage14.Controls.Add(this.lfs1);
            this.tabPage14.Controls.Add(this.label32);
            this.tabPage14.Controls.Add(this.label33);
            this.tabPage14.Controls.Add(this.label34);
            this.tabPage14.Controls.Add(this.label35);
            this.tabPage14.Location = new System.Drawing.Point(4, 25);
            this.tabPage14.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage14.Size = new System.Drawing.Size(425, 448);
            this.tabPage14.TabIndex = 1;
            this.tabPage14.Text = "File Modified Rates";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // lbt
            // 
            this.lbt.AutoSize = true;
            this.lbt.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbt.ForeColor = System.Drawing.Color.Black;
            this.lbt.Location = new System.Drawing.Point(229, 164);
            this.lbt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbt.Name = "lbt";
            this.lbt.Size = new System.Drawing.Size(58, 23);
            this.lbt.TabIndex = 45;
            this.lbt.Text = "label15";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Black;
            this.label31.Location = new System.Drawing.Point(25, 160);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(152, 23);
            this.label31.TabIndex = 43;
            this.label31.Text = "Start Time             :";
            // 
            // lfs4
            // 
            this.lfs4.AutoSize = true;
            this.lfs4.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lfs4.ForeColor = System.Drawing.Color.Black;
            this.lfs4.Location = new System.Drawing.Point(229, 126);
            this.lfs4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lfs4.Name = "lfs4";
            this.lfs4.Size = new System.Drawing.Size(58, 23);
            this.lfs4.TabIndex = 42;
            this.lfs4.Text = "label15";
            // 
            // lfs3
            // 
            this.lfs3.AutoSize = true;
            this.lfs3.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lfs3.ForeColor = System.Drawing.Color.Black;
            this.lfs3.Location = new System.Drawing.Point(229, 91);
            this.lfs3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lfs3.Name = "lfs3";
            this.lfs3.Size = new System.Drawing.Size(58, 23);
            this.lfs3.TabIndex = 41;
            this.lfs3.Text = "label15";
            // 
            // lfs2
            // 
            this.lfs2.AutoSize = true;
            this.lfs2.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lfs2.ForeColor = System.Drawing.Color.Black;
            this.lfs2.Location = new System.Drawing.Point(229, 59);
            this.lfs2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lfs2.Name = "lfs2";
            this.lfs2.Size = new System.Drawing.Size(58, 23);
            this.lfs2.TabIndex = 40;
            this.lfs2.Text = "label15";
            // 
            // lfs1
            // 
            this.lfs1.AutoSize = true;
            this.lfs1.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lfs1.ForeColor = System.Drawing.Color.Black;
            this.lfs1.Location = new System.Drawing.Point(229, 23);
            this.lfs1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lfs1.Name = "lfs1";
            this.lfs1.Size = new System.Drawing.Size(58, 23);
            this.lfs1.TabIndex = 39;
            this.lfs1.Text = "label15";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Black;
            this.label32.Location = new System.Drawing.Point(25, 126);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(155, 23);
            this.label32.TabIndex = 36;
            this.label32.Text = "File rename rate     :";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Black;
            this.label33.Location = new System.Drawing.Point(19, 91);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(158, 23);
            this.label33.TabIndex = 37;
            this.label33.Text = "File change rate      :";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(25, 59);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(153, 23);
            this.label34.TabIndex = 33;
            this.label34.Text = "File deletion  rate   :";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Black;
            this.label35.Location = new System.Drawing.Point(27, 23);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(153, 23);
            this.label35.TabIndex = 32;
            this.label35.Text = "File creation rate    :";
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.lstf);
            this.tabPage15.Location = new System.Drawing.Point(4, 25);
            this.tabPage15.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage15.Size = new System.Drawing.Size(425, 448);
            this.tabPage15.TabIndex = 2;
            this.tabPage15.Text = "Files with Suspicious Behaviour";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // lstf
            // 
            this.lstf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstf.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstf.ForeColor = System.Drawing.Color.Black;
            this.lstf.GridLines = true;
            this.lstf.HideSelection = false;
            this.lstf.Location = new System.Drawing.Point(4, 4);
            this.lstf.Margin = new System.Windows.Forms.Padding(4);
            this.lstf.Name = "lstf";
            this.lstf.Size = new System.Drawing.Size(417, 440);
            this.lstf.TabIndex = 1;
            this.lstf.UseCompatibleStateImageBehavior = false;
            this.lstf.View = System.Windows.Forms.View.List;
            // 
            // tabPage16
            // 
            this.tabPage16.Controls.Add(this.lfa4);
            this.tabPage16.Controls.Add(this.lfa3);
            this.tabPage16.Controls.Add(this.lfa2);
            this.tabPage16.Controls.Add(this.lfa1);
            this.tabPage16.Location = new System.Drawing.Point(4, 25);
            this.tabPage16.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage16.Size = new System.Drawing.Size(425, 448);
            this.tabPage16.TabIndex = 3;
            this.tabPage16.Text = "Status";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // lfa4
            // 
            this.lfa4.AutoSize = true;
            this.lfa4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lfa4.ForeColor = System.Drawing.Color.Black;
            this.lfa4.Location = new System.Drawing.Point(27, 142);
            this.lfa4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lfa4.Name = "lfa4";
            this.lfa4.Size = new System.Drawing.Size(54, 17);
            this.lfa4.TabIndex = 37;
            this.lfa4.Text = "label15";
            // 
            // lfa3
            // 
            this.lfa3.AutoSize = true;
            this.lfa3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lfa3.ForeColor = System.Drawing.Color.Black;
            this.lfa3.Location = new System.Drawing.Point(27, 107);
            this.lfa3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lfa3.Name = "lfa3";
            this.lfa3.Size = new System.Drawing.Size(54, 17);
            this.lfa3.TabIndex = 36;
            this.lfa3.Text = "label15";
            // 
            // lfa2
            // 
            this.lfa2.AutoSize = true;
            this.lfa2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lfa2.ForeColor = System.Drawing.Color.Black;
            this.lfa2.Location = new System.Drawing.Point(27, 75);
            this.lfa2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lfa2.Name = "lfa2";
            this.lfa2.Size = new System.Drawing.Size(54, 17);
            this.lfa2.TabIndex = 35;
            this.lfa2.Text = "label15";
            // 
            // lfa1
            // 
            this.lfa1.AutoSize = true;
            this.lfa1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lfa1.ForeColor = System.Drawing.Color.Black;
            this.lfa1.Location = new System.Drawing.Point(27, 41);
            this.lfa1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lfa1.Name = "lfa1";
            this.lfa1.Size = new System.Drawing.Size(54, 17);
            this.lfa1.TabIndex = 34;
            this.lfa1.Text = "label15";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.tabControl5);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage7.Size = new System.Drawing.Size(877, 485);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "Dos Layer";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // tabControl5
            // 
            this.tabControl5.Controls.Add(this.tabPage17);
            this.tabControl5.Controls.Add(this.tabPage20);
            this.tabControl5.Controls.Add(this.tabPage21);
            this.tabControl5.Controls.Add(this.tabPage22);
            this.tabControl5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl5.Location = new System.Drawing.Point(4, 4);
            this.tabControl5.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl5.Name = "tabControl5";
            this.tabControl5.SelectedIndex = 0;
            this.tabControl5.Size = new System.Drawing.Size(869, 477);
            this.tabControl5.TabIndex = 0;
            // 
            // tabPage17
            // 
            this.tabPage17.Controls.Add(this.lsvip);
            this.tabPage17.Location = new System.Drawing.Point(4, 25);
            this.tabPage17.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage17.Size = new System.Drawing.Size(861, 448);
            this.tabPage17.TabIndex = 0;
            this.tabPage17.Text = "IP Packets";
            this.tabPage17.UseVisualStyleBackColor = true;
            // 
            // lsvip
            // 
            this.lsvip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsvip.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lsvip.GridLines = true;
            this.lsvip.HideSelection = false;
            this.lsvip.Location = new System.Drawing.Point(4, 4);
            this.lsvip.Margin = new System.Windows.Forms.Padding(4);
            this.lsvip.Name = "lsvip";
            this.lsvip.Size = new System.Drawing.Size(853, 440);
            this.lsvip.TabIndex = 1;
            this.lsvip.UseCompatibleStateImageBehavior = false;
            this.lsvip.View = System.Windows.Forms.View.Details;
            // 
            // tabPage20
            // 
            this.tabPage20.Controls.Add(this.lstpdet);
            this.tabPage20.Location = new System.Drawing.Point(4, 25);
            this.tabPage20.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Size = new System.Drawing.Size(861, 448);
            this.tabPage20.TabIndex = 3;
            this.tabPage20.Text = "IP Log Entries";
            this.tabPage20.UseVisualStyleBackColor = true;
            // 
            // lstpdet
            // 
            this.lstpdet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstpdet.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lstpdet.GridLines = true;
            this.lstpdet.HideSelection = false;
            this.lstpdet.Location = new System.Drawing.Point(0, 0);
            this.lstpdet.Margin = new System.Windows.Forms.Padding(4);
            this.lstpdet.Name = "lstpdet";
            this.lstpdet.Size = new System.Drawing.Size(861, 448);
            this.lstpdet.TabIndex = 1;
            this.lstpdet.UseCompatibleStateImageBehavior = false;
            this.lstpdet.View = System.Windows.Forms.View.Details;
            // 
            // tabPage21
            // 
            this.tabPage21.Controls.Add(this.lbpds);
            this.tabPage21.Controls.Add(this.lbpd);
            this.tabPage21.Controls.Add(this.lbrp);
            this.tabPage21.Controls.Add(this.label30);
            this.tabPage21.Controls.Add(this.lbnfa);
            this.tabPage21.Controls.Add(this.llbduc);
            this.tabPage21.Location = new System.Drawing.Point(4, 25);
            this.tabPage21.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage21.Name = "tabPage21";
            this.tabPage21.Size = new System.Drawing.Size(861, 448);
            this.tabPage21.TabIndex = 4;
            this.tabPage21.Text = "Packet Information";
            this.tabPage21.UseVisualStyleBackColor = true;
            // 
            // lbpds
            // 
            this.lbpds.AutoSize = true;
            this.lbpds.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lbpds.ForeColor = System.Drawing.Color.Black;
            this.lbpds.Location = new System.Drawing.Point(292, 167);
            this.lbpds.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbpds.Name = "lbpds";
            this.lbpds.Size = new System.Drawing.Size(16, 17);
            this.lbpds.TabIndex = 43;
            this.lbpds.Text = "a";
            // 
            // lbpd
            // 
            this.lbpd.AutoSize = true;
            this.lbpd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lbpd.ForeColor = System.Drawing.Color.Black;
            this.lbpd.Location = new System.Drawing.Point(292, 105);
            this.lbpd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbpd.Name = "lbpd";
            this.lbpd.Size = new System.Drawing.Size(16, 17);
            this.lbpd.TabIndex = 42;
            this.lbpd.Text = "a";
            // 
            // lbrp
            // 
            this.lbrp.AutoSize = true;
            this.lbrp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lbrp.ForeColor = System.Drawing.Color.Black;
            this.lbrp.Location = new System.Drawing.Point(287, 48);
            this.lbrp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbrp.Name = "lbrp";
            this.lbrp.Size = new System.Drawing.Size(16, 17);
            this.lbrp.TabIndex = 41;
            this.lbrp.Text = "a";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label30.ForeColor = System.Drawing.Color.Black;
            this.label30.Location = new System.Drawing.Point(19, 169);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(180, 17);
            this.label30.TabIndex = 40;
            this.label30.Text = "Total Packets discarded    :";
            // 
            // lbnfa
            // 
            this.lbnfa.AutoSize = true;
            this.lbnfa.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lbnfa.ForeColor = System.Drawing.Color.Black;
            this.lbnfa.Location = new System.Drawing.Point(20, 106);
            this.lbnfa.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbnfa.Name = "lbnfa";
            this.lbnfa.Size = new System.Drawing.Size(176, 17);
            this.lbnfa.TabIndex = 39;
            this.lbnfa.Text = "Total Packets delivered    :";
            // 
            // llbduc
            // 
            this.llbduc.AutoSize = true;
            this.llbduc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.llbduc.ForeColor = System.Drawing.Color.Black;
            this.llbduc.Location = new System.Drawing.Point(19, 47);
            this.llbduc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbduc.Name = "llbduc";
            this.llbduc.Size = new System.Drawing.Size(189, 17);
            this.llbduc.TabIndex = 38;
            this.llbduc.Text = "Total Received Packets     :  ";
            // 
            // tabPage22
            // 
            this.tabPage22.Controls.Add(this.lstip);
            this.tabPage22.Location = new System.Drawing.Point(4, 25);
            this.tabPage22.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage22.Name = "tabPage22";
            this.tabPage22.Size = new System.Drawing.Size(861, 448);
            this.tabPage22.TabIndex = 5;
            this.tabPage22.Text = "IPs under Survillance";
            this.tabPage22.UseVisualStyleBackColor = true;
            // 
            // lstip
            // 
            this.lstip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstip.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lstip.ForeColor = System.Drawing.Color.Red;
            this.lstip.FormattingEnabled = true;
            this.lstip.ItemHeight = 17;
            this.lstip.Location = new System.Drawing.Point(0, 0);
            this.lstip.Margin = new System.Windows.Forms.Padding(4);
            this.lstip.Name = "lstip";
            this.lstip.Size = new System.Drawing.Size(861, 448);
            this.lstip.TabIndex = 24;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.tabControl6);
            this.tabPage8.Location = new System.Drawing.Point(4, 25);
            this.tabPage8.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(877, 485);
            this.tabPage8.TabIndex = 2;
            this.tabPage8.Text = "R2L Layer";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // tabControl6
            // 
            this.tabControl6.Controls.Add(this.tabPage23);
            this.tabControl6.Controls.Add(this.tabPage24);
            this.tabControl6.Controls.Add(this.tabPage25);
            this.tabControl6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl6.Location = new System.Drawing.Point(0, 0);
            this.tabControl6.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl6.Name = "tabControl6";
            this.tabControl6.SelectedIndex = 0;
            this.tabControl6.Size = new System.Drawing.Size(877, 485);
            this.tabControl6.TabIndex = 0;
            // 
            // tabPage23
            // 
            this.tabPage23.Controls.Add(this.lstdns);
            this.tabPage23.Location = new System.Drawing.Point(4, 25);
            this.tabPage23.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage23.Name = "tabPage23";
            this.tabPage23.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage23.Size = new System.Drawing.Size(869, 456);
            this.tabPage23.TabIndex = 0;
            this.tabPage23.Text = "DNS Packets";
            this.tabPage23.UseVisualStyleBackColor = true;
            // 
            // lstdns
            // 
            this.lstdns.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstdns.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lstdns.ForeColor = System.Drawing.Color.Black;
            this.lstdns.GridLines = true;
            this.lstdns.HideSelection = false;
            this.lstdns.Location = new System.Drawing.Point(4, 4);
            this.lstdns.Margin = new System.Windows.Forms.Padding(4);
            this.lstdns.Name = "lstdns";
            this.lstdns.Size = new System.Drawing.Size(861, 448);
            this.lstdns.TabIndex = 8;
            this.lstdns.UseCompatibleStateImageBehavior = false;
            this.lstdns.View = System.Windows.Forms.View.Details;
            // 
            // tabPage24
            // 
            this.tabPage24.Location = new System.Drawing.Point(4, 25);
            this.tabPage24.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage24.Name = "tabPage24";
            this.tabPage24.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage24.Size = new System.Drawing.Size(869, 456);
            this.tabPage24.TabIndex = 1;
            this.tabPage24.Text = "Active IP";
            this.tabPage24.UseVisualStyleBackColor = true;
            // 
            // tabPage25
            // 
            this.tabPage25.Controls.Add(this.lsvdet);
            this.tabPage25.Location = new System.Drawing.Point(4, 25);
            this.tabPage25.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage25.Name = "tabPage25";
            this.tabPage25.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage25.Size = new System.Drawing.Size(869, 456);
            this.tabPage25.TabIndex = 2;
            this.tabPage25.Text = "Anomaly Detected";
            this.tabPage25.UseVisualStyleBackColor = true;
            // 
            // lsvdet
            // 
            this.lsvdet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsvdet.HideSelection = false;
            this.lsvdet.Location = new System.Drawing.Point(4, 4);
            this.lsvdet.Margin = new System.Windows.Forms.Padding(4);
            this.lsvdet.Name = "lsvdet";
            this.lsvdet.Size = new System.Drawing.Size(861, 448);
            this.lsvdet.TabIndex = 1;
            this.lsvdet.UseCompatibleStateImageBehavior = false;
            this.lsvdet.View = System.Windows.Forms.View.List;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(161)))), ((int)(((byte)(226)))));
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Image = global::Regression.Properties.Resources.icons8_shutdown_64;
            this.button4.Location = new System.Drawing.Point(0, 440);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(275, 74);
            this.button4.TabIndex = 7;
            this.button4.Text = "Close";
            this.button4.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // lstadet
            // 
            this.lstadet.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader18,
            this.columnHeader19,
            this.columnHeader20});
            this.lstadet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstadet.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstadet.HideSelection = false;
            this.lstadet.Location = new System.Drawing.Point(0, 0);
            this.lstadet.Margin = new System.Windows.Forms.Padding(4);
            this.lstadet.Name = "lstadet";
            this.lstadet.Size = new System.Drawing.Size(275, 514);
            this.lstadet.TabIndex = 3;
            this.lstadet.UseCompatibleStateImageBehavior = false;
            this.lstadet.View = System.Windows.Forms.View.Details;
            this.lstadet.SelectedIndexChanged += new System.EventHandler(this.lstadet_SelectedIndexChanged);
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "LAYER";
            this.columnHeader18.Width = 100;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "ANOMALY DETECTOR";
            this.columnHeader19.Width = 100;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "DETECT TIME";
            this.columnHeader20.Width = 100;
            // 
            // MemoryTimer
            // 
            this.MemoryTimer.Enabled = true;
            this.MemoryTimer.Interval = 1000;
            this.MemoryTimer.Tick += new System.EventHandler(this.MemoryTimer_Tick);
            // 
            // Programstimer
            // 
            this.Programstimer.Enabled = true;
            this.Programstimer.Interval = 5000;
            this.Programstimer.Tick += new System.EventHandler(this.Programstimer_Tick);
            // 
            // tmrEditNotify
            // 
            this.tmrEditNotify.Enabled = true;
            this.tmrEditNotify.Tick += new System.EventHandler(this.tmrEditNotify_Tick);
            // 
            // ProcessMonitoring
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1165, 514);
            this.Controls.Add(this.splitContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ProcessMonitoring";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProcessMonitoring";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.ProcessMonitoring_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage10.ResumeLayout(false);
            this.tabControl4.ResumeLayout(false);
            this.tabPage13.ResumeLayout(false);
            this.tabPage14.ResumeLayout(false);
            this.tabPage14.PerformLayout();
            this.tabPage15.ResumeLayout(false);
            this.tabPage16.ResumeLayout(false);
            this.tabPage16.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabControl5.ResumeLayout(false);
            this.tabPage17.ResumeLayout(false);
            this.tabPage20.ResumeLayout(false);
            this.tabPage21.ResumeLayout(false);
            this.tabPage21.PerformLayout();
            this.tabPage22.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            this.tabControl6.ResumeLayout(false);
            this.tabPage23.ResumeLayout(false);
            this.tabPage25.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Timer MemoryTimer;
        private System.Windows.Forms.Timer Programstimer;
        private System.Windows.Forms.Timer tmrEditNotify;
        private System.Windows.Forms.ListView lstadet;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.ListBox lstnet;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.ListView listView4;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.Label lbt;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label lfs4;
        private System.Windows.Forms.Label lfs3;
        private System.Windows.Forms.Label lfs2;
        private System.Windows.Forms.Label lfs1;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.ListView lstf;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.Label lfa4;
        private System.Windows.Forms.Label lfa3;
        private System.Windows.Forms.Label lfa2;
        private System.Windows.Forms.Label lfa1;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabControl tabControl5;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.ListView lsvip;
        private System.Windows.Forms.TabPage tabPage20;
        private System.Windows.Forms.ListView lstpdet;
        private System.Windows.Forms.TabPage tabPage21;
        private System.Windows.Forms.Label lbpds;
        private System.Windows.Forms.Label lbpd;
        private System.Windows.Forms.Label lbrp;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label lbnfa;
        private System.Windows.Forms.Label llbduc;
        private System.Windows.Forms.TabPage tabPage22;
        private System.Windows.Forms.ListBox lstip;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabControl tabControl6;
        private System.Windows.Forms.TabPage tabPage23;
        private System.Windows.Forms.ListView lstdns;
        private System.Windows.Forms.TabPage tabPage24;
        private System.Windows.Forms.TabPage tabPage25;
        private System.Windows.Forms.ListView lsvdet;

    }
}